--
-- PostgreSQL database dump
--

\restrict OdDuFJKP380cucFIn0y1TaNjcMsDgMddHfR80W2nSdwijnWyIz30G65VqzjdxaK

-- Dumped from database version 15.15 (Debian 15.15-1.pgdg13+1)
-- Dumped by pg_dump version 15.15 (Debian 15.15-1.pgdg13+1)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: optionstatus; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.optionstatus AS ENUM (
    'OPEN',
    'CLOSED',
    'EXPIRED',
    'ASSIGNED'
);


ALTER TYPE public.optionstatus OWNER TO postgres;

--
-- Name: optionstrategy; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.optionstrategy AS ENUM (
    'COVERED_CALL',
    'CASH_SECURED_PUT'
);


ALTER TYPE public.optionstrategy OWNER TO postgres;

--
-- Name: optiontype; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.optiontype AS ENUM (
    'CALL',
    'PUT'
);


ALTER TYPE public.optiontype OWNER TO postgres;

--
-- Name: transactiontype; Type: TYPE; Schema: public; Owner: postgres
--

CREATE TYPE public.transactiontype AS ENUM (
    'BUY_STOCK',
    'SELL_STOCK',
    'SELL_CALL',
    'BUY_CALL',
    'SELL_PUT',
    'BUY_PUT',
    'ASSIGNMENT',
    'DIVIDEND',
    'DEPOSIT',
    'WITHDRAWAL',
    'OPTION_EXPIRY'
);


ALTER TYPE public.transactiontype OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: migrations; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.migrations (
    id integer NOT NULL,
    filename character varying(255) NOT NULL,
    applied_at timestamp with time zone DEFAULT now()
);


ALTER TABLE public.migrations OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.migrations_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.migrations_id_seq OWNER TO postgres;

--
-- Name: migrations_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.migrations_id_seq OWNED BY public.migrations.id;


--
-- Name: options; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.options (
    id integer NOT NULL,
    stock_id integer NOT NULL,
    ticker character varying NOT NULL,
    option_type public.optiontype NOT NULL,
    strategy public.optionstrategy NOT NULL,
    strike_price double precision NOT NULL,
    contracts integer NOT NULL,
    premium_per_contract double precision NOT NULL,
    total_premium double precision NOT NULL,
    expiration_date timestamp with time zone NOT NULL,
    status public.optionstatus,
    opened_at timestamp with time zone NOT NULL,
    closed_at timestamp with time zone,
    closing_premium double precision,
    realized_pnl double precision,
    notes character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.options OWNER TO postgres;

--
-- Name: options_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.options_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.options_id_seq OWNER TO postgres;

--
-- Name: options_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.options_id_seq OWNED BY public.options.id;


--
-- Name: stocks; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.stocks (
    id integer NOT NULL,
    user_id integer NOT NULL,
    ticker character varying NOT NULL,
    company_name character varying NOT NULL,
    shares double precision NOT NULL,
    average_cost double precision NOT NULL,
    total_invested double precision NOT NULL,
    total_premium_earned double precision,
    adjusted_cost_basis double precision NOT NULL,
    is_active boolean,
    notes character varying,
    created_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.stocks OWNER TO postgres;

--
-- Name: stocks_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.stocks_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.stocks_id_seq OWNER TO postgres;

--
-- Name: stocks_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.stocks_id_seq OWNED BY public.stocks.id;


--
-- Name: transactions; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.transactions (
    id integer NOT NULL,
    stock_id integer,
    option_id integer,
    ticker character varying NOT NULL,
    transaction_type public.transactiontype NOT NULL,
    quantity double precision NOT NULL,
    price double precision NOT NULL,
    total_amount double precision NOT NULL,
    commission double precision,
    notes character varying,
    transaction_date timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now(),
    user_id integer NOT NULL
);


ALTER TABLE public.transactions OWNER TO postgres;

--
-- Name: transactions_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.transactions_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.transactions_id_seq OWNER TO postgres;

--
-- Name: transactions_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.transactions_id_seq OWNED BY public.transactions.id;


--
-- Name: users; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.users (
    id integer NOT NULL,
    email character varying NOT NULL,
    username character varying NOT NULL,
    hashed_password character varying NOT NULL,
    created_at timestamp without time zone,
    updated_at timestamp without time zone,
    cash_balance double precision DEFAULT 0.0,
    afp_allocation jsonb
);


ALTER TABLE public.users OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.users_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.users_id_seq OWNER TO postgres;

--
-- Name: users_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.users_id_seq OWNED BY public.users.id;


--
-- Name: watchlist; Type: TABLE; Schema: public; Owner: postgres
--

CREATE TABLE public.watchlist (
    id integer NOT NULL,
    user_id integer NOT NULL,
    ticker character varying NOT NULL,
    company_name character varying,
    target_price double precision,
    notes text,
    added_at timestamp with time zone DEFAULT now(),
    updated_at timestamp with time zone
);


ALTER TABLE public.watchlist OWNER TO postgres;

--
-- Name: watchlist_id_seq; Type: SEQUENCE; Schema: public; Owner: postgres
--

CREATE SEQUENCE public.watchlist_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE public.watchlist_id_seq OWNER TO postgres;

--
-- Name: watchlist_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: postgres
--

ALTER SEQUENCE public.watchlist_id_seq OWNED BY public.watchlist.id;


--
-- Name: migrations id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations ALTER COLUMN id SET DEFAULT nextval('public.migrations_id_seq'::regclass);


--
-- Name: options id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.options ALTER COLUMN id SET DEFAULT nextval('public.options_id_seq'::regclass);


--
-- Name: stocks id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stocks ALTER COLUMN id SET DEFAULT nextval('public.stocks_id_seq'::regclass);


--
-- Name: transactions id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions ALTER COLUMN id SET DEFAULT nextval('public.transactions_id_seq'::regclass);


--
-- Name: users id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users ALTER COLUMN id SET DEFAULT nextval('public.users_id_seq'::regclass);


--
-- Name: watchlist id; Type: DEFAULT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.watchlist ALTER COLUMN id SET DEFAULT nextval('public.watchlist_id_seq'::regclass);


--
-- Data for Name: migrations; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.migrations (id, filename, applied_at) FROM stdin;
1	001_add_user_id.sql	2026-06-11 18:27:45.95176+00
2	002_add_user_id_to_transactions.sql	2026-06-11 18:28:06.189611+00
3	003_create_watchlist.sql	2026-06-11 18:28:06.193987+00
4	004_add_cash_balance_and_deposit_withdrawal.sql	2026-06-11 18:28:06.195748+00
5	005_add_afp_allocation.sql	2026-06-11 18:28:06.197006+00
\.


--
-- Data for Name: options; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.options (id, stock_id, ticker, option_type, strategy, strike_price, contracts, premium_per_contract, total_premium, expiration_date, status, opened_at, closed_at, closing_premium, realized_pnl, notes, created_at, updated_at) FROM stdin;
1	3	MARA	CALL	COVERED_CALL	8.5	2	0.18	36	2026-02-27 00:00:00+00	CLOSED	2026-02-19 18:58:20.656+00	2026-02-26 09:58:47+00	0.415	-47	Test edit OK	2026-02-19 04:30:49.10879+00	2026-03-01 04:08:43.060712+00
5	3	MARA	CALL	COVERED_CALL	8.5	2	0.25	52	2026-02-20 00:00:00+00	CLOSED	2026-02-05 00:00:00+00	2026-02-19 00:00:00+00	0.02	48	Covered call original - cerrada en rollover del 19 feb	2026-02-20 03:03:11.201536+00	2026-02-20 03:03:11.201536+00
6	11	BTBT	CALL	COVERED_CALL	2	3	0.1	30	2026-03-27 00:00:00+00	EXPIRED	2026-02-27 13:09:13+00	2026-03-27 00:00:00+00	\N	30	\N	2026-03-01 02:26:22.206656+00	2026-04-01 14:07:00.934442+00
7	3	MARA	CALL	COVERED_CALL	9.5	2	0.53	106	2026-03-27 00:00:00+00	EXPIRED	2026-02-26 09:56:47+00	2026-03-27 00:00:00+00	\N	106	Roll desde 8.5 FEB27 → 9.5 MAR27	2026-03-01 02:29:46.778067+00	2026-04-01 14:07:00.934442+00
8	3	MARA	CALL	COVERED_CALL	8.5	2	0.31	62	2026-04-10 00:00:00+00	EXPIRED	2026-04-01 10:08:57+00	2026-04-10 00:00:00+00	\N	62	\N	2026-04-10 15:01:51.259105+00	2026-04-13 14:46:17.916495+00
9	18	F	CALL	COVERED_CALL	12	1	0.13	13	2026-05-08 00:00:00+00	CLOSED	2026-05-01 12:00:41+00	2026-05-08 00:00:00+00	0.22	-9	\N	2026-05-08 12:18:02.792611+00	2026-05-08 15:22:38.700067+00
10	18	F	CALL	COVERED_CALL	12	1	0.26	26	2026-05-15 00:00:00+00	EXPIRED	2026-05-08 00:00:00+00	2026-05-15 00:00:00+00	\N	26	\N	2026-05-08 15:22:38.700067+00	2026-05-18 15:07:35.748467+00
11	11	BTBT	CALL	COVERED_CALL	2.5	8	0.1	80	2026-05-22 00:00:00+00	EXPIRED	2026-05-11 13:26:00+00	2026-05-22 00:00:00+00	\N	80	\N	2026-05-11 18:39:54.361945+00	2026-05-26 17:24:08.136364+00
14	18	F	CALL	COVERED_CALL	13	1	0.16	16	2026-05-22 00:00:00+00	EXPIRED	2026-05-19 10:26:32+00	2026-05-22 00:00:00+00	\N	16	\N	2026-05-20 20:20:13.166779+00	2026-05-26 17:24:08.136364+00
15	19	SMR	CALL	COVERED_CALL	13	2	0.49	98	2026-06-05 00:00:00+00	EXPIRED	2026-05-27 13:48:00+00	2026-06-05 00:00:00+00	\N	98	\N	2026-05-27 17:49:22.441605+00	2026-06-08 13:46:00.658232+00
16	19	SMR	CALL	COVERED_CALL	12	2	0.22	44	2026-06-12 00:00:00+00	EXPIRED	2026-06-08 09:58:00+00	2026-06-12 00:00:00+00	\N	44	\N	2026-06-08 14:07:59.633318+00	2026-06-15 01:53:40.242836+00
17	19	SMR	CALL	COVERED_CALL	11	1	0.33	33	2026-06-18 00:00:00+00	CLOSED	2026-06-15 11:03:00+00	2026-06-18 00:00:00+00	0.43	-10	\N	2026-06-15 15:05:45.800339+00	2026-06-18 23:01:50.660878+00
18	19	SMR	CALL	COVERED_CALL	11.5	2	0.59	118	2026-06-26 00:00:00+00	EXPIRED	2026-06-18 00:00:00+00	2026-06-26 00:00:00+00	\N	118	\N	2026-06-18 23:01:50.660878+00	2026-06-29 18:37:41.065645+00
19	19	SMR	CALL	COVERED_CALL	11	2	0.6	120	2026-07-17 00:00:00+00	EXPIRED	2026-06-29 14:55:12+00	2026-07-17 00:00:00+00	\N	120	\N	2026-07-21 00:21:01.29221+00	2026-07-23 02:46:38.061642+00
20	19	SMR	CALL	COVERED_CALL	10	2	0.54	108	2026-08-21 00:00:00+00	OPEN	2026-07-21 12:42:40+00	\N	\N	\N	\N	2026-07-23 02:46:55.851919+00	\N
\.


--
-- Data for Name: stocks; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.stocks (id, user_id, ticker, company_name, shares, average_cost, total_invested, total_premium_earned, adjusted_cost_basis, is_active, notes, created_at, updated_at) FROM stdin;
18	1	F	Ford Motor Company	0	12.84	0	16	12.84	f	\N	2026-05-08 12:18:02.792611+00	2026-05-26 17:26:18.144351+00
11	1	BTBT	BTBT	0	1.8974	0	106	1.8974	f	\N	2026-02-22 18:05:59.740038+00	2026-05-26 17:26:18.144351+00
4	1	AI	AI	0	14.4533	0	0	14.4533	f	\N	2026-02-22 17:19:43.582758+00	2026-02-22 18:05:59.740038+00
5	1	IBRX	IBRX	0	2.445	0	0	2.445	f	\N	2026-02-22 17:19:43.582758+00	2026-02-22 18:05:59.740038+00
7	1	MRNA	MRNA	0	23.606	0	0	23.606	f	\N	2026-02-22 17:19:43.582758+00	2026-02-22 18:05:59.740038+00
10	1	RDW	RDW	0	7.9626	0	0	7.9626	f	\N	2026-02-22 17:19:43.582758+00	2026-02-22 18:05:59.740038+00
19	1	SMR	NuScale Power Corporation	265	11.4262	3027.9429999999998	471	9.6488	t	\N	2026-05-27 17:49:22.441605+00	2026-07-23 02:46:55.851919+00
12	1	TSLA	TSLA	0	180.37	0	0	180.37	f	\N	2026-02-22 19:38:22.113853+00	2026-02-22 19:46:50.302338+00
13	1	CCJ	CCJ	0	23.2543	0	0	23.2543	f	\N	2026-02-22 19:38:45.078596+00	2026-02-22 19:46:50.302338+00
14	1	FNV	FNV	0	143.2049	0	0	143.2049	f	\N	2026-02-22 19:38:56.329551+00	2026-02-22 19:46:50.302338+00
15	1	SLV	SLV	0	21.6377	0	0	21.6377	f	\N	2026-02-22 19:38:56.329551+00	2026-02-22 19:46:50.302338+00
16	1	SLVP	SLVP	0	13.1	0	0	13.1	f	\N	2026-02-22 19:46:50.302338+00	\N
17	1	LCID	LCID	0	16.506	0	0	16.506	f	\N	2026-02-22 19:46:50.302338+00	\N
6	1	KHC	KHC	0	25.305	0	0	25.305	f	\N	2026-02-22 17:19:43.582758+00	2026-03-01 02:15:47.512177+00
3	1	MARA	MARA	0	7.9794	0	169	7.9794	f	\N	2026-02-19 04:27:12.608026+00	2026-04-13 14:47:55.603086+00
8	1	MSTR	MSTR	0	159.8775	0	0	159.8775	f	\N	2026-02-22 17:19:43.582758+00	2026-05-08 12:18:02.792611+00
9	1	QBTS	QBTS	0	30.88	0	0	30.88	f	\N	2026-02-22 17:19:43.582758+00	2026-05-26 17:26:18.144351+00
\.


--
-- Data for Name: transactions; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.transactions (id, stock_id, option_id, ticker, transaction_type, quantity, price, total_amount, commission, notes, transaction_date, created_at, user_id) FROM stdin;
4	3	1	MARA	SELL_CALL	2	0.18	36	0	\N	2026-02-19 04:30:49.113927+00	2026-02-19 04:30:49.10879+00	1
9	3	5	MARA	BUY_CALL	2	0.02	4	0	Buy to close - rollover del 19 feb	2026-02-19 00:00:00+00	2026-02-20 03:03:32.578403+00	1
10	4	\N	AI	BUY_STOCK	10	17.7	177	1.0002	Importado desde IB	2025-10-17 09:30:01+00	2026-02-22 17:19:43.582758+00	1
11	4	\N	AI	BUY_STOCK	20	12.83	256.6	1.0004	Importado desde IB	2025-11-21 09:30:01+00	2026-02-22 17:19:43.582758+00	1
12	\N	\N	CCJ	SELL_STOCK	7	79.6712	557.7	1.0014	Importado desde IB	2025-07-24 13:42:42+00	2026-02-22 17:19:43.582758+00	1
13	\N	\N	CCJ	SELL_STOCK	3	81.11	243.33	1.0006	Importado desde IB	2025-09-15 12:51:27+00	2026-02-22 17:19:43.582758+00	1
14	\N	\N	CCJ	SELL_STOCK	5	86.51	432.55	1.0009	Importado desde IB	2025-10-20 10:10:49+00	2026-02-22 17:19:43.582758+00	1
15	5	\N	IBRX	BUY_STOCK	100	2.445	244.5	1.0022	Importado desde IB	2025-10-20 11:23:29+00	2026-02-22 17:19:43.582758+00	1
16	6	\N	KHC	BUY_STOCK	10	25.305	253.05	1.0002	Importado desde IB	2025-10-06 15:27:45+00	2026-02-22 17:19:43.582758+00	1
17	\N	\N	LCID	BUY_STOCK	10	16.506	165.06	1.0002	Importado desde IB	2025-09-05 09:30:54+00	2026-02-22 17:19:43.582758+00	1
18	\N	\N	LCID	SELL_STOCK	10	19.6	196	1.0019	Importado desde IB	2025-09-15 14:01:53+00	2026-02-22 17:19:43.582758+00	1
19	3	\N	MARA	BUY_STOCK	10	16.35	163.5	1.0002	Importado desde IB	2025-07-30 15:06:18+00	2026-02-22 17:19:43.582758+00	1
20	3	\N	MARA	BUY_STOCK	10	16.42	164.2	1.0002	Importado desde IB	2025-07-31 09:30:00+00	2026-02-22 17:19:43.582758+00	1
21	3	\N	MARA	BUY_STOCK	10	15.56	155.6	1.0002	Importado desde IB	2025-08-01 09:30:01+00	2026-02-22 17:19:43.582758+00	1
22	3	\N	MARA	SELL_STOCK	30	20.7507	622.52	1.0056	Importado desde IB	2025-10-20 10:14:25+00	2026-02-22 17:19:43.582758+00	1
23	3	\N	MARA	BUY_STOCK	20	11.6993	233.99	1.0004	Importado desde IB	2025-11-19 10:06:10+00	2026-02-22 17:19:43.582758+00	1
24	3	\N	MARA	BUY_STOCK	20	10.12	202.4	1.0004	Importado desde IB	2025-11-21 09:30:00+00	2026-02-22 17:19:43.582758+00	1
25	7	\N	MRNA	BUY_STOCK	5	23.605	118.03	1.0001	Importado desde IB	2025-09-12 15:47:18+00	2026-02-22 17:19:43.582758+00	1
26	8	\N	MSTR	BUY_STOCK	2	156	312	1	Importado desde IB	2025-12-31 09:30:01+00	2026-02-22 17:19:43.582758+00	1
27	9	\N	QBTS	BUY_STOCK	10	37.52	375.2	1.0002	Importado desde IB	2025-10-20 10:35:02+00	2026-02-22 17:19:43.582758+00	1
28	10	\N	RDW	BUY_STOCK	25	7.875	196.88	1.0006	Importado desde IB	2025-09-17 14:39:03+00	2026-02-22 17:19:43.582758+00	1
29	10	\N	RDW	BUY_STOCK	25	8.05	201.25	1.0006	Importado desde IB	2025-10-20 10:18:56+00	2026-02-22 17:19:43.582758+00	1
30	\N	\N	SLV	SELL_STOCK	15	35.465	531.98	1.0029	Importado desde IB	2025-07-24 13:44:15+00	2026-02-22 17:19:43.582758+00	1
31	\N	\N	SLV	SELL_STOCK	5.2944	38.6147	204.44	1.001	Importado desde IB	2025-09-15 13:14:11+00	2026-02-22 17:19:43.582758+00	1
32	\N	\N	SLV	SELL_STOCK	5	69.11	345.55	1.0008	Importado desde IB	2025-12-30 09:30:00+00	2026-02-22 17:19:43.582758+00	1
33	\N	\N	SLV	SELL_STOCK	5	65.56	327.8	1.0008	Importado desde IB	2025-12-31 09:30:00+00	2026-02-22 17:19:43.582758+00	1
34	\N	\N	TSLA	SELL_STOCK	1	303.06	303.06	1.0002	Importado desde IB	2025-07-24 14:10:20+00	2026-02-22 17:19:43.582758+00	1
35	6	\N	KHC	DIVIDEND	0	0	4	0	KHC(US5007541064) Cash Dividend USD 0.40 per Share (Ordinary Dividend)	2025-12-26 00:00:00+00	2026-02-22 17:19:43.582758+00	1
36	4	\N	AI	SELL_STOCK	30	10.3407	310.22	1.0058	Importado desde IB	2026-02-05 13:23:10+00	2026-02-22 18:05:59.740038+00	1
37	11	\N	BTBT	BUY_STOCK	200	2.145	429	1	Importado desde IB	2026-01-22 10:29:09+00	2026-02-22 18:05:59.740038+00	1
38	5	\N	IBRX	SELL_STOCK	80	6.355	508.4	1.0156	Importado desde IB	2026-01-21 12:55:36+00	2026-02-22 18:05:59.740038+00	1
39	5	\N	IBRX	SELL_STOCK	20	5.785	115.7	1.0039	Importado desde IB	2026-02-05 11:16:54+00	2026-02-22 18:05:59.740038+00	1
40	3	\N	MARA	BUY_STOCK	60	7.5	450	1	Importado desde IB	2026-02-05 11:32:49+00	2026-02-22 18:05:59.740038+00	1
41	3	\N	MARA	BUY_STOCK	100	7.095	709.5	1	Importado desde IB	2026-02-05 13:26:14+00	2026-02-22 18:05:59.740038+00	1
42	7	\N	MRNA	SELL_STOCK	5	42.175	210.88	1.001	Importado desde IB	2026-02-05 11:16:02+00	2026-02-22 18:05:59.740038+00	1
43	8	\N	MSTR	BUY_STOCK	2	163.7571	327.51	1	Importado desde IB	2026-01-07 12:58:29+00	2026-02-22 18:05:59.740038+00	1
44	9	\N	QBTS	BUY_STOCK	5	17.6	88	0.88	Importado desde IB	2026-02-05 15:00:45+00	2026-02-22 18:05:59.740038+00	1
45	10	\N	RDW	SELL_STOCK	50	9.2	460	1.0097	Importado desde IB	2026-02-05 12:23:28+00	2026-02-22 18:05:59.740038+00	1
46	3	\N	MARA	SELL_CALL	2	0.26	52	1.4041	IB | MARA 20FEB26 8.5 C | Strike $8.5 | Exp 2026-02-20	2026-02-05 13:30:07+00	2026-02-22 18:05:59.740038+00	1
47	\N	\N	CCJ	SELL_STOCK	15.102	49.8999	753.59	1.0085	Importado desde IB	2024-01-16 11:41:10+00	2026-02-22 19:38:22.113853+00	1
48	\N	\N	FNV	SELL_STOCK	0.6983	117.45	82.02	0.8225	Importado desde IB	2024-06-20 15:27:28+00	2026-02-22 19:38:22.113853+00	1
49	12	\N	TSLA	BUY_STOCK	1	180.3695	180.37	1	Importado desde IB	2024-06-20 15:25:51+00	2026-02-22 19:38:22.113853+00	1
50	\N	\N	FNV	DIVIDEND	0	0	0.25	0	FNV (CA3518581051) Cash Dividend USD 0.36 (Ordinary Dividend)	2024-03-28 00:00:00+00	2026-02-22 19:38:22.113853+00	1
51	\N	\N	FNV	DIVIDEND	0	0	0.25	0	FNV (CA3518581051) Cash Dividend USD 0.36 (Ordinary Dividend)	2024-06-27 00:00:00+00	2026-02-22 19:38:22.113853+00	1
52	\N	\N	CCJ	DIVIDEND	0	0	1.68	0	CCJ(CA13321L1085) Cash Dividend USD 0.112332 per Share (Ordinary Dividend)	2024-12-13 00:00:00+00	2026-02-22 19:38:22.113853+00	1
53	\N	\N	FNV	DIVIDEND	0	0	0.24	0	FNV (CA3518581051) Cash Dividend USD 0.34 (Ordinary Dividend)	2023-03-30 00:00:00+00	2026-02-22 19:38:35.417509+00	1
54	\N	\N	FNV	DIVIDEND	0	0	0.24	0	FNV (CA3518581051) Cash Dividend USD 0.34 (Ordinary Dividend)	2023-06-29 00:00:00+00	2026-02-22 19:38:35.417509+00	1
55	\N	\N	FNV	DIVIDEND	0	0	0.24	0	FNV (CA3518581051) Cash Dividend USD 0.34 (Ordinary Dividend)	2023-09-28 00:00:00+00	2026-02-22 19:38:35.417509+00	1
56	\N	\N	CCJ	DIVIDEND	0	0	2.7	0	CCJ(CA13321L1085) Cash Dividend USD 0.089659 per Share (Ordinary Dividend)	2023-12-15 00:00:00+00	2026-02-22 19:38:35.417509+00	1
57	\N	\N	FNV	DIVIDEND	0	0	0.24	0	FNV (CA3518581051) Cash Dividend USD 0.34 (Ordinary Dividend)	2023-12-21 00:00:00+00	2026-02-22 19:38:35.417509+00	1
58	13	\N	CCJ	BUY_STOCK	4.3649	22.9095	100	1	Importado desde IB	2022-01-06 10:09:01+00	2026-02-22 19:38:45.078596+00	1
59	13	\N	CCJ	BUY_STOCK	4.3824	22.8181	100	1	Importado desde IB	2022-01-11 09:50:04+00	2026-02-22 19:38:45.078596+00	1
60	13	\N	CCJ	BUY_STOCK	4.5248	22.1	100	1	Importado desde IB	2022-01-20 09:51:42+00	2026-02-22 19:38:45.078596+00	1
61	13	\N	CCJ	BUY_STOCK	2.5589	19.5393	50	0.5	Importado desde IB	2022-02-04 12:10:16+00	2026-02-22 19:38:45.078596+00	1
62	\N	\N	FNV	DIVIDEND	0	0	0.22	0	FNV (CA3518581051) Cash Dividend USD 0.32 (Ordinary Dividend)	2022-03-31 00:00:00+00	2026-02-22 19:38:45.078596+00	1
63	\N	\N	FNV	DIVIDEND	0	0	0.22	0	FNV (CA3518581051) Cash Dividend USD 0.32 (Ordinary Dividend)	2022-06-30 00:00:00+00	2026-02-22 19:38:45.078596+00	1
64	\N	\N	FNV	DIVIDEND	0	0	0.22	0	FNV (CA3518581051) Cash Dividend USD 0.32 (Ordinary Dividend)	2022-09-29 00:00:00+00	2026-02-22 19:38:45.078596+00	1
65	13	\N	CCJ	DIVIDEND	0	0	2.64	0	CCJ(CA13321L1085) Cash Dividend USD 0.087837 per Share (Ordinary Dividend)	2022-12-15 00:00:00+00	2026-02-22 19:38:45.078596+00	1
66	\N	\N	FNV	DIVIDEND	0	0	0.22	0	FNV (CA3518581051) Cash Dividend USD 0.32 (Ordinary Dividend)	2022-12-22 00:00:00+00	2026-02-22 19:38:45.078596+00	1
67	13	\N	CCJ	BUY_STOCK	3.8703	25.8372	100	1	Importado desde IB	2021-11-19 09:31:01+00	2026-02-22 19:38:56.329551+00	1
68	13	\N	CCJ	BUY_STOCK	3.9888	25.0698	100	1	Importado desde IB	2021-11-22 09:42:27+00	2026-02-22 19:38:56.329551+00	1
69	13	\N	CCJ	BUY_STOCK	4.1597	24.0396	100	1	Importado desde IB	2021-11-26 09:30:00+00	2026-02-22 19:38:56.329551+00	1
70	13	\N	CCJ	BUY_STOCK	2.2522	22.2	50	0.5	Importado desde IB	2021-12-28 11:12:45+00	2026-02-22 19:38:56.329551+00	1
71	14	\N	FNV	BUY_STOCK	0.6983	143.2	100	1	Importado desde IB	2021-11-04 11:35:17+00	2026-02-22 19:38:56.329551+00	1
72	15	\N	SLV	BUY_STOCK	5	21.1	105.5	1	Importado desde IB	2021-09-22 14:00:00+00	2026-02-22 19:38:56.329551+00	1
73	15	\N	SLV	BUY_STOCK	4.4843	22.2996	100	1	Importado desde IB	2021-11-09 10:06:04+00	2026-02-22 19:38:56.329551+00	1
74	15	\N	SLV	BUY_STOCK	4.4247	22.6	100	1	Importado desde IB	2021-11-22 09:30:41+00	2026-02-22 19:38:56.329551+00	1
75	15	\N	SLV	BUY_STOCK	4.6062	21.7098	100	1	Importado desde IB	2021-11-23 09:30:00+00	2026-02-22 19:38:56.329551+00	1
76	15	\N	SLV	BUY_STOCK	4.6361	21.5694	100	1	Importado desde IB	2021-11-23 11:01:59+00	2026-02-22 19:38:56.329551+00	1
77	15	\N	SLV	BUY_STOCK	2.3584	21.2	50	0.5	Importado desde IB	2021-11-29 11:03:15+00	2026-02-22 19:38:56.329551+00	1
78	15	\N	SLV	BUY_STOCK	4.7847	20.8999	100	1	Importado desde IB	2021-12-29 09:30:00+00	2026-02-22 19:38:56.329551+00	1
79	\N	\N	SLVP	BUY_STOCK	5	13.1	65.5	0.655	Importado desde IB	2021-09-22 12:09:22+00	2026-02-22 19:38:56.329551+00	1
80	\N	\N	SLVP	SELL_STOCK	5	13.97	69.85	0.6995	Importado desde IB	2021-11-03 15:46:33+00	2026-02-22 19:38:56.329551+00	1
81	13	\N	CCJ	DIVIDEND	0	0	0.75	0	CCJ(CA13321L1085) Cash Dividend USD 0.06192 per Share (Ordinary Dividend)	2021-12-15 00:00:00+00	2026-02-22 19:38:56.329551+00	1
82	14	\N	FNV	DIVIDEND	0	0	0.21	0	FNV (CA3518581051) Cash Dividend USD 0.30 (Ordinary Dividend)	2021-12-23 00:00:00+00	2026-02-22 19:38:56.329551+00	1
83	11	\N	BTBT	BUY_STOCK	100	1.748	174.8	1	Importado desde IB	2026-02-26 14:03:33+00	2026-03-01 02:15:47.512177+00	1
84	11	\N	BTBT	BUY_STOCK	50	1.755	87.75	0.8775	Importado desde IB	2026-02-26 14:07:24+00	2026-03-01 02:15:47.512177+00	1
85	6	\N	KHC	SELL_STOCK	10	24.515	245.15	1.0019	Importado desde IB	2026-02-26 13:59:03+00	2026-03-01 02:15:47.512177+00	1
86	11	\N	BTBT	SELL_CALL	3	0.1	30	2.1061	IB | BTBT 27MAR26 2 C | Strike $2.0 | Exp 2026-03-27	2026-02-27 13:09:13+00	2026-03-01 02:15:47.512177+00	1
87	3	\N	MARA	BUY_CALL	1	0.41	41	1.0513	IB | MARA 27FEB26 8.5 C | Strike $8.5 | Exp 2026-02-27	2026-02-26 09:56:47+00	2026-03-01 02:15:47.512177+00	1
88	3	\N	MARA	BUY_CALL	1	0.42	42	1.0513	IB | MARA 27FEB26 8.5 C | Strike $8.5 | Exp 2026-02-27	2026-02-26 09:58:47+00	2026-03-01 02:15:47.512177+00	1
89	3	\N	MARA	SELL_CALL	1	0.53	53	1.0545	IB | MARA 27MAR26 9.5 C | Strike $9.5 | Exp 2026-03-27	2026-02-26 09:56:47+00	2026-03-01 02:15:47.512177+00	1
90	3	\N	MARA	SELL_CALL	1	0.53	53	1.0545	IB | MARA 27MAR26 9.5 C | Strike $9.5 | Exp 2026-03-27	2026-02-26 09:58:47+00	2026-03-01 02:15:47.512177+00	1
91	11	\N	BTBT	BUY_STOCK	50	1.348	67.4	0.674	Importado desde IB	2026-04-01 10:11:41+00	2026-04-10 15:01:51.259105+00	1
92	11	\N	BTBT	BUY_CALL	3	0	0	0	IB | BTBT 27MAR26 2 C | Strike $2.0 | Exp 2026-03-27	2026-03-27 16:20:00+00	2026-04-10 15:01:51.259105+00	1
93	3	\N	MARA	BUY_CALL	2	0	0	0	IB | MARA 27MAR26 9.5 C | Strike $9.5 | Exp 2026-03-27	2026-03-27 16:20:00+00	2026-04-10 15:01:51.259105+00	1
94	3	\N	MARA	SELL_CALL	2	0.31	62	1.4025	IB | MARA 10APR26 8.5 C | Strike $8.5 | Exp 2026-04-10	2026-04-01 10:08:57+00	2026-04-10 15:01:51.259105+00	1
95	3	\N	MARA	SELL_STOCK	200	8.5	1700	0.074	Importado desde IB	2026-04-10 16:20:00+00	2026-04-13 14:47:55.603086+00	1
96	3	\N	MARA	BUY_CALL	2	0	0	0	IB | MARA 10APR26 8.5 C | Strike $8.5 | Exp 2026-04-10	2026-04-10 16:20:00+00	2026-04-13 14:47:55.603086+00	1
97	18	\N	F	BUY_STOCK	100	11.57	1157	1	Importado desde IB	2026-04-30 09:33:32+00	2026-05-08 12:18:02.792611+00	1
98	8	\N	MSTR	SELL_STOCK	4	166.07	664.28	1.0145	Importado desde IB	2026-04-30 14:57:21+00	2026-05-08 12:18:02.792611+00	1
99	18	\N	F	SELL_CALL	1	0.13	13	1.0518	IB | F 08MAY26 12 C | Strike $12.0 | Exp 2026-05-08	2026-05-01 12:00:41+00	2026-05-08 12:18:02.792611+00	1
100	18	\N	F	SELL_CALL	1	0.26	26	0	IB | F May15'26 12 Call | Strike $12.0 | Exp 2026-05-15	2026-05-08 00:00:00+00	2026-05-08 15:22:38.700067+00	1
101	18	\N	F	BUY_CALL	1	0.22	22	0	IB | F May08'26 12 Call | Strike $12.0 | Exp 2026-05-08	2026-05-08 00:00:00+00	2026-05-08 15:22:38.700067+00	1
102	11	\N	BTBT	SELL_CALL	2	0.1	20	1.4	IB | BTBT May22'26 2.5 Call | Strike $2.5 | Exp 2026-05-22	2026-05-11 13:26:00+00	2026-05-11 18:39:54.361945+00	1
103	11	\N	BTBT	SELL_CALL	1	0.1	10	0.7	IB | BTBT May22'26 2.5 Call | Strike $2.5 | Exp 2026-05-22	2026-05-11 13:26:00+00	2026-05-11 18:39:54.361945+00	1
104	11	\N	BTBT	SELL_CALL	1	0.1	10	0.7	IB | BTBT May22'26 2.5 Call | Strike $2.5 | Exp 2026-05-22	2026-05-11 13:26:00+00	2026-05-11 18:39:54.361945+00	1
105	18	\N	F	SELL_STOCK	100	12	1200	0.0442	Importado desde IB	2026-05-15 16:20:00+00	2026-05-20 20:20:13.166779+00	1
106	18	\N	F	BUY_STOCK	100	12.84	1284	1.0003	Importado desde IB	2026-05-19 10:25:06+00	2026-05-20 20:20:13.166779+00	1
107	11	\N	BTBT	SELL_CALL	4	0.1	40	2.807	IB | BTBT 22MAY26 2.5 C | Strike $2.5 | Exp 2026-05-22	2026-05-11 13:26:17+00	2026-05-20 20:20:13.166779+00	1
108	18	\N	F	BUY_CALL	1	0	0	0	IB | F 15MAY26 12 C | Strike $12.0 | Exp 2026-05-15	2026-05-15 16:20:00+00	2026-05-20 20:20:13.166779+00	1
109	18	\N	F	SELL_CALL	1	0.16	16	1.4519	IB | F 22MAY26 13 C | Strike $13.0 | Exp 2026-05-22	2026-05-19 10:26:32+00	2026-05-20 20:20:13.166779+00	1
110	11	\N	BTBT	SELL_STOCK	400	2.052	820.8	2.0961	Importado desde IB	2026-05-22 13:37:13+00	2026-05-26 17:26:18.144351+00	1
111	18	\N	F	SELL_STOCK	100	13	1300	0.0463	Importado desde IB	2026-05-22 16:20:00+00	2026-05-26 17:26:18.144351+00	1
112	9	\N	QBTS	SELL_STOCK	15	29.6809	445.21	1.0121	Importado desde IB	2026-05-22 13:38:49+00	2026-05-26 17:26:18.144351+00	1
113	11	\N	BTBT	BUY_CALL	4	0.01	4	0.727	IB | BTBT 22MAY26 2.5 C | Strike $2.5 | Exp 2026-05-22	2026-05-22 13:34:19+00	2026-05-26 17:26:18.144351+00	1
114	18	\N	F	BUY_CALL	1	0	0	0	IB | F 22MAY26 13 C | Strike $13.0 | Exp 2026-05-22	2026-05-22 16:20:00+00	2026-05-26 17:26:18.144351+00	1
115	19	\N	SMR	SELL_CALL	1	0.49	49	1.06	IB | SMR Jun05'26 13 Call | Strike $13.0 | Exp 2026-06-05	2026-05-27 13:48:00+00	2026-05-27 17:49:22.441605+00	1
116	19	\N	SMR	SELL_CALL	1	0.49	49	0.36	IB | SMR Jun05'26 13 Call | Strike $13.0 | Exp 2026-06-05	2026-05-27 13:48:00+00	2026-05-27 17:49:22.441605+00	1
117	19	\N	SMR	BUY_STOCK	95	12.078	1147.41	1	Importado desde IB	2026-05-27 13:46:00+00	2026-05-27 17:49:22.441605+00	1
118	19	\N	SMR	BUY_STOCK	105	12.0775	1268.14	0	Importado desde IB	2026-05-27 13:46:00+00	2026-05-27 17:49:22.441605+00	1
119	19	\N	SMR	SELL_CALL	1	0.22	22	0.14	IB | SMR Jun12'26 12 Call | Strike $12.0 | Exp 2026-06-12	2026-06-08 09:58:00+00	2026-06-08 14:07:59.633318+00	1
120	19	\N	SMR	SELL_CALL	1	0.22	22	0.56	IB | SMR Jun12'26 12 Call | Strike $12.0 | Exp 2026-06-12	2026-06-08 09:58:00+00	2026-06-08 14:07:59.633318+00	1
121	19	\N	SMR	OPTION_EXPIRY	2	0	0	0	Expiración | SMR Jun05 '26 13 Call | Strike $13.0 | Exp 2026-06-05	2026-06-05 23:44:00+00	2026-06-08 14:07:59.633318+00	1
122	19	\N	SMR	BUY_STOCK	30	9.685	290.55	1	Importado desde IB	2026-06-09 12:19:00+00	2026-06-09 16:20:35.596135+00	1
123	19	\N	SMR	OPTION_EXPIRY	2	0	0	0	Expiración | SMR Jun12'26 12 Call | Strike $12.0 | Exp 2026-06-12	2026-06-14 00:00:00+00	2026-06-15 02:38:39.372209+00	1
124	19	\N	SMR	SELL_CALL	2	0.33	66	1.4	IB | SMR Jun18'26 11 Call | Strike $11.0 | Exp 2026-06-18	2026-06-15 11:03:00+00	2026-06-15 15:05:45.800339+00	1
125	19	\N	SMR	BUY_CALL	1	0.4	40	1.05	IB | SMR Jun18'26 11 Call | Strike $11.0 | Exp 2026-06-18	2026-06-18 00:00:00+00	2026-06-18 23:01:50.660878+00	1
126	19	\N	SMR	SELL_CALL	1	0.58	58	1.06	IB | SMR Jun26'26 11.5 Call | Strike $11.5 | Exp 2026-06-26	2026-06-18 00:00:00+00	2026-06-18 23:01:50.660878+00	1
127	19	\N	SMR	BUY_CALL	1	0.43	43	1.05	IB | SMR Jun18'26 11 Call | Strike $11.0 | Exp 2026-06-18	2026-06-18 00:00:00+00	2026-06-18 23:01:50.660878+00	1
128	19	\N	SMR	SELL_CALL	1	0.6	60	1.06	IB | SMR Jun26'26 11.5 Call | Strike $11.5 | Exp 2026-06-26	2026-06-18 00:00:00+00	2026-06-18 23:01:50.660878+00	1
129	19	\N	SMR	BUY_STOCK	15	9.04	135.6	1	Importado desde IB	2026-07-09 00:00:00+00	2026-07-10 03:16:26.47276+00	1
130	19	\N	SMR	BUY_STOCK	10	10.0493	100.49	1	Importado desde IB	2026-06-26 12:26:41+00	2026-07-21 00:21:01.29221+00	1
131	19	\N	SMR	BUY_CALL	2	0	0	0	IB | SMR 26JUN26 11.5 C | Strike $11.5 | Exp 2026-06-26	2026-06-26 16:20:00+00	2026-07-21 00:21:01.29221+00	1
132	19	\N	SMR	SELL_CALL	2	0.6	120	1.4056	IB | SMR 17JUL26 11 C | Strike $11.0 | Exp 2026-07-17	2026-06-29 14:55:12+00	2026-07-21 00:21:01.29221+00	1
133	19	\N	SMR	BUY_CALL	2	0	0	0	IB | SMR 17JUL26 11 C | Strike $11.0 | Exp 2026-07-17	2026-07-17 16:20:00+00	2026-07-21 00:21:01.29221+00	1
134	18	\N	F	DIVIDEND	0	0	15	0	F(US3453708600) Payment in Lieu of Dividend (Ordinary Dividend)	2026-06-01 00:00:00+00	2026-07-21 00:21:01.29221+00	1
135	19	\N	SMR	BUY_STOCK	10	8.575	85.75	0.8575	Importado desde IB	2026-07-21 12:43:31+00	2026-07-23 02:46:55.851919+00	1
136	19	\N	SMR	SELL_CALL	2	0.54	108	1.4034	IB | SMR 21AUG26 10 C | Strike $10.0 | Exp 2026-08-21	2026-07-21 12:42:40+00	2026-07-23 02:46:55.851919+00	1
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.users (id, email, username, hashed_password, created_at, updated_at, cash_balance, afp_allocation) FROM stdin;
1	mhrehbein@gmail.com	admin	$2b$12$bhU1VLKg00VxMLsGCtEaIuJOaAgfR6Q06FJ5MXIx1KDPaJ/FEoj2W	2026-02-06 03:00:40.652237	2026-08-05 19:33:46.542688	42.67	{"A": 0, "B": 0, "C": 0, "D": 40, "E": 60}
\.


--
-- Data for Name: watchlist; Type: TABLE DATA; Schema: public; Owner: postgres
--

COPY public.watchlist (id, user_id, ticker, company_name, target_price, notes, added_at, updated_at) FROM stdin;
2	1	F	Ford Motor Company	\N		2026-03-02 02:06:50.77999+00	\N
\.


--
-- Name: migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.migrations_id_seq', 5, true);


--
-- Name: options_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.options_id_seq', 20, true);


--
-- Name: stocks_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.stocks_id_seq', 19, true);


--
-- Name: transactions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.transactions_id_seq', 136, true);


--
-- Name: users_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.users_id_seq', 1, true);


--
-- Name: watchlist_id_seq; Type: SEQUENCE SET; Schema: public; Owner: postgres
--

SELECT pg_catalog.setval('public.watchlist_id_seq', 2, true);


--
-- Name: migrations migrations_filename_key; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_filename_key UNIQUE (filename);


--
-- Name: migrations migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.migrations
    ADD CONSTRAINT migrations_pkey PRIMARY KEY (id);


--
-- Name: options options_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.options
    ADD CONSTRAINT options_pkey PRIMARY KEY (id);


--
-- Name: stocks stocks_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stocks
    ADD CONSTRAINT stocks_pkey PRIMARY KEY (id);


--
-- Name: transactions transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: watchlist watchlist_pkey; Type: CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.watchlist
    ADD CONSTRAINT watchlist_pkey PRIMARY KEY (id);


--
-- Name: idx_stocks_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_stocks_user_id ON public.stocks USING btree (user_id);


--
-- Name: idx_transactions_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_transactions_user_id ON public.transactions USING btree (user_id);


--
-- Name: idx_watchlist_ticker; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_watchlist_ticker ON public.watchlist USING btree (ticker);


--
-- Name: idx_watchlist_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX idx_watchlist_user_id ON public.watchlist USING btree (user_id);


--
-- Name: idx_watchlist_user_ticker; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX idx_watchlist_user_ticker ON public.watchlist USING btree (user_id, ticker);


--
-- Name: ix_options_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_options_id ON public.options USING btree (id);


--
-- Name: ix_options_ticker; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_options_ticker ON public.options USING btree (ticker);


--
-- Name: ix_stocks_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_stocks_id ON public.stocks USING btree (id);


--
-- Name: ix_stocks_ticker; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_stocks_ticker ON public.stocks USING btree (ticker);


--
-- Name: ix_stocks_user_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_stocks_user_id ON public.stocks USING btree (user_id);


--
-- Name: ix_transactions_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_transactions_id ON public.transactions USING btree (id);


--
-- Name: ix_transactions_ticker; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_transactions_ticker ON public.transactions USING btree (ticker);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_users_id ON public.users USING btree (id);


--
-- Name: ix_users_username; Type: INDEX; Schema: public; Owner: postgres
--

CREATE UNIQUE INDEX ix_users_username ON public.users USING btree (username);


--
-- Name: ix_watchlist_id; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_watchlist_id ON public.watchlist USING btree (id);


--
-- Name: ix_watchlist_ticker; Type: INDEX; Schema: public; Owner: postgres
--

CREATE INDEX ix_watchlist_ticker ON public.watchlist USING btree (ticker);


--
-- Name: stocks fk_stocks_user_id; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stocks
    ADD CONSTRAINT fk_stocks_user_id FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: transactions fk_transactions_user; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT fk_transactions_user FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: options options_stock_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.options
    ADD CONSTRAINT options_stock_id_fkey FOREIGN KEY (stock_id) REFERENCES public.stocks(id);


--
-- Name: stocks stocks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.stocks
    ADD CONSTRAINT stocks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: transactions transactions_option_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_option_id_fkey FOREIGN KEY (option_id) REFERENCES public.options(id);


--
-- Name: transactions transactions_stock_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.transactions
    ADD CONSTRAINT transactions_stock_id_fkey FOREIGN KEY (stock_id) REFERENCES public.stocks(id);


--
-- Name: watchlist watchlist_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: postgres
--

ALTER TABLE ONLY public.watchlist
    ADD CONSTRAINT watchlist_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- PostgreSQL database dump complete
--

\unrestrict OdDuFJKP380cucFIn0y1TaNjcMsDgMddHfR80W2nSdwijnWyIz30G65VqzjdxaK

